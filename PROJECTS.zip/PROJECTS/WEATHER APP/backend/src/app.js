const express = require('express');
const path = require('path');
const app = express();
const hbs = require('hbs');
const port = process.env.PORT || 8000;

// Set the 'views' directory and the view engine
app.set('views', path.join(__dirname, '../views'));
const templatepath=  path.join(__dirname, '../templates/views');
const partialspath = path.join(__dirname, '../templates/partials');
app.set('view engine', 'hbs');
app.set('views' , templatepath);
hbs.registerPartials(partialspath);

const staticpath = path.join(__dirname, '../public');

app.use(express.static(staticpath));

app.get('', (_req, res) => {
    res.render('index');
});

app.get('/about', (_req, res) => {
    res.render('about');
});

app.get('/weather', (_req, res) => {
    res.render('weather');
});

app.get('*', (_req, res) => {
    res.render('404notfound');
});

app.listen(port, () => {
    console.log(`Listening on port ${port}`);
});
